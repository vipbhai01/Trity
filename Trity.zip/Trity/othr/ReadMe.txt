___________      .__  __          
\__    ___/______|__|/  |_ ___.__.
  |    |  \_  __ \  \   __<   |  |
  |    |   |  | \/  ||  |  \___  |
  |____|   |__|  |__||__|  / ____|
                           \/       ReadMe
---------------------------------------------------------------------------------
Name: Trity v3.0.1
Author: @_t0x1c aka toxic
Contact Info: @_t0x1c on Instagram or toxicnull@gmail.com on Skype
---------------------------------------------------------------------------------
Unless your smart enough to fix it, don't change any of the files and than ask
me to help you if it screws up, I wont.
---------------------------------------------------------------------------------
Bugs, problems or anything I should know of? Let me know and direct message me on instagram
at @_t0x1c.
If errors occur, try restarting Trity. Still not working? Contact me above. ^^
---------------------------------------------------------------------------------
If your gonna use some of my source, please ask me and give credits pls :)
Don't wanna get exposed? Give creds :/
I AM NOT RESPONSIBLE FOR WHAT YOU DO WITH THIS PROGRAM. TRITY WAS MADE PURELY FOR GOOD.
---------------------------------------------------------------------------------
You might need:
- An Internet connection
- Dictionary attack list
- Phone/Email
- Linux is a must-have
---------------------------------------------------------------------------------
